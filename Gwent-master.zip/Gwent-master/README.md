# Gwent
A standalone multiplayer gwent clone

This is a very basic attempt to clone the Witcher 3 mini-CCG and allow for multiplayer. 

Currently the game has very basic functionality in gameplay and deck building.
